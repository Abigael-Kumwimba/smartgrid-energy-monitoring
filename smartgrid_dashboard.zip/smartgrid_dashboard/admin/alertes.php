<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/dashboard_data.php';

$user = smartgrid_require_login(['admin']);
$conn = dashboard_db();
$stmt = $conn->prepare(
    'SELECT a.date_alerte, a.niveau, a.message, cp.numero_compteur, cl.nom AS client_nom, cl.telegram_chat_id
     FROM alertes a
     LEFT JOIN compteurs cp ON cp.id = a.id_compteur
     LEFT JOIN clients cl ON cl.id = cp.id_client
     ORDER BY a.date_alerte DESC
     LIMIT 150'
);
$rows = fetch_all_assoc($stmt);
$totalAlerts = count($rows);
$criticalCount = count(array_filter($rows, static fn($row) => $row['niveau'] === 'critique'));
$warningCount = count(array_filter($rows, static fn($row) => $row['niveau'] === 'warning'));
$telegramReady = count(array_filter($rows, static fn($row) => !empty($row['telegram_chat_id'])));
$latestAlert = $rows[0] ?? null;
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Alertes SmartGrid</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="/AdminLTE-4.0.0-rc7/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="/smartgrid_dashboard/assets/smartgrid-theme.css">
  <style>
    body{background:#0f1020;color:#fff;font-family:'Source Sans 3',sans-serif}.wrap{max-width:1220px;margin:0 auto;padding:32px}.panel{background:#181a2f;border:1px solid rgba(255,255,255,.07);border-radius:24px;padding:24px;box-shadow:0 18px 48px rgba(0,0,0,.28)}.metric{border-radius:22px;padding:18px;min-height:124px;position:relative;overflow:hidden}.metric:after{content:"";position:absolute;right:-28px;top:-28px;width:92px;height:92px;border-radius:999px;background:rgba(255,255,255,.15)}.tone-red{background:linear-gradient(135deg,#ff4d6d,#ff8a5b)}.tone-yellow{background:linear-gradient(135deg,#ffb44d,#ffd166)}.tone-blue{background:linear-gradient(135deg,#2b86ff,#49d2ff)}.tone-green{background:linear-gradient(135deg,#0da878,#29d391)}.metric-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:15px;background:rgba(255,255,255,.18);font-size:1.2rem}.table{color:#fff}.table>*{border-color:rgba(255,255,255,.06)!important}.muted{color:#a4acc4}.level-badge{border-radius:999px;padding:.4rem .75rem;font-weight:800}.level-warning{background:rgba(255,180,77,.16);color:#ffd18a}.level-critique{background:rgba(255,107,122,.16);color:#ff9da8}.level-info{background:rgba(73,184,255,.16);color:#9addff}.search-input{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);color:#fff;border-radius:16px}.search-input::placeholder{color:#a4acc4}.status-ok{color:#29d391}.status-missing{color:#ffb44d}.last-card{background:linear-gradient(135deg,rgba(255,107,122,.12),rgba(255,180,77,.08));border:1px solid rgba(255,255,255,.08);border-radius:22px;padding:18px}.empty-state{text-align:center;color:#a4acc4;padding:28px}.test-card{background:linear-gradient(135deg,rgba(73,184,255,.13),rgba(41,211,145,.09));border:1px solid rgba(255,255,255,.08);border-radius:22px;padding:18px}.test-status{min-height:24px}.telegram-btn{border-radius:999px}
  </style>
</head>
<body class="sg-admin">
<div class="wrap">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h1 class="h3 mb-1">Alertes et anomalies</h1>
      <div class="muted">Detection automatique des sous-tensions, surtensions, surcharges et surintensites</div>
      <div class="test-status small mt-2" id="telegram-test-status"></div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <button class="btn btn-primary telegram-btn" id="telegram-test-btn" type="button">
        <i class="bi bi-send-check me-1"></i> Envoyer la derniere alerte
      </button>
      <a class="btn btn-outline-light" href="/smartgrid_dashboard/admin/index.php">Dashboard</a>
      <a class="btn btn-outline-light" href="/smartgrid_dashboard/logout.php">Deconnexion</a>
    </div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6"><div class="metric tone-blue"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Alertes totales</div><div class="display-6 fw-bold"><?= $totalAlerts ?></div><div class="small">historique recent</div></div><div class="metric-icon"><i class="bi bi-bell"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-red"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Critiques</div><div class="display-6 fw-bold"><?= $criticalCount ?></div><div class="small">action rapide</div></div><div class="metric-icon"><i class="bi bi-exclamation-triangle"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-yellow"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Warnings</div><div class="display-6 fw-bold"><?= $warningCount ?></div><div class="small">surveillance</div></div><div class="metric-icon"><i class="bi bi-activity"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-green"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Clients notifiables</div><div class="display-6 fw-bold"><?= $telegramReady ?></div><div class="small">Telegram configure</div></div><div class="metric-icon"><i class="bi bi-send-check"></i></div></div></div></div>
  </div>
  <div class="row g-4 mb-4">
    <div class="col-12">
      <div class="panel h-100">
        <h2 class="h5 mb-3">Derniere alerte</h2>
        <?php if ($latestAlert): ?>
          <div class="last-card">
            <div class="d-flex justify-content-between mb-2"><strong><?= htmlspecialchars($latestAlert['numero_compteur'] ?? '-') ?></strong><span class="level-badge level-<?= htmlspecialchars($latestAlert['niveau']) ?>"><?= htmlspecialchars($latestAlert['niveau']) ?></span></div>
            <div class="muted small mb-2"><?= htmlspecialchars($latestAlert['date_alerte']) ?></div>
            <div><?= htmlspecialchars($latestAlert['message']) ?></div>
            <div class="mt-2 muted">Client : <?= htmlspecialchars($latestAlert['client_nom'] ?? '-') ?></div>
  </div>
        <?php else: ?>
          <div class="empty-state">Aucune alerte enregistree.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="panel">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
      <div><h2 class="h5 mb-0">Historique des alertes</h2><div class="muted small">Recherche par client, compteur, niveau ou message</div></div>
      <div class="d-flex gap-2 flex-wrap"><input class="form-control search-input" id="alert-search" placeholder="Rechercher..."><span class="badge text-bg-dark align-self-center" id="rows-count"><?= count($rows) ?> lignes</span></div>
    </div>
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead><tr><th>Date</th><th>Client</th><th>Compteur</th><th>Niveau</th><th>Message</th><th>Notification client</th></tr></thead>
        <tbody id="alert-table-body">
        <?php foreach ($rows as $row): ?>
          <tr data-search="<?= htmlspecialchars(strtolower(($row['date_alerte'] ?? '') . ' ' . ($row['client_nom'] ?? '') . ' ' . ($row['numero_compteur'] ?? '') . ' ' . ($row['niveau'] ?? '') . ' ' . ($row['message'] ?? ''))) ?>">
            <td><?= htmlspecialchars($row['date_alerte']) ?></td>
            <td><?= htmlspecialchars($row['client_nom'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['numero_compteur'] ?? '-') ?></td>
            <td><span class="level-badge level-<?= htmlspecialchars($row['niveau']) ?>"><?= htmlspecialchars($row['niveau']) ?></span></td>
            <td><?= htmlspecialchars($row['message']) ?></td>
            <td><?= !empty($row['telegram_chat_id']) ? '<span class="status-ok">Telegram configure</span>' : '<span class="status-missing">Chat ID manquant</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
          <tr><td colspan="6" class="empty-state">Aucune alerte disponible.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
const search = document.getElementById('alert-search');
const rowsCount = document.getElementById('rows-count');
const telegramBtn = document.getElementById('telegram-test-btn');
const telegramStatus = document.getElementById('telegram-test-status');
search.addEventListener('input', () => {
  const query = search.value.trim().toLowerCase();
  let visible = 0;
  document.querySelectorAll('#alert-table-body tr[data-search]').forEach((row) => {
    const show = row.dataset.search.includes(query);
    row.style.display = show ? '' : 'none';
    if (show) visible += 1;
  });
  rowsCount.textContent = `${visible} lignes`;
});
telegramBtn.addEventListener('click', async () => {
  telegramBtn.disabled = true;
  telegramStatus.className = 'test-status small mt-3 text-info';
  telegramStatus.textContent = 'Envoi de la derniere alerte...';
  try {
    const response = await fetch('/smartgrid_dashboard/smartgrid_app/api/send_latest_alert_telegram.php', { method: 'POST' });
    const data = await response.json();
    telegramStatus.className = data.status === 'success' ? 'test-status small mt-3 text-success' : 'test-status small mt-3 text-warning';
    telegramStatus.textContent = data.message || 'Envoi termine.';
  } catch (error) {
    telegramStatus.className = 'test-status small mt-3 text-warning';
    telegramStatus.textContent = 'Impossible de contacter le serveur Telegram.';
  } finally {
    telegramBtn.disabled = false;
  }
});
</script>
</body>
</html>

