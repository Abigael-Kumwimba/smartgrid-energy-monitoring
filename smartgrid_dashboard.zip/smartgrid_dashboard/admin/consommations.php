﻿<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/dashboard_data.php';

$user = smartgrid_require_login(['admin']);
$conn = dashboard_db();
$stmt = $conn->prepare(
    'SELECT co.date_mesure, cl.nom AS client_nom, cp.numero_compteur, co.tension, co.courant, co.puissance, co.energie
     FROM consommations co
     LEFT JOIN compteurs cp ON cp.id = co.id_compteur
     LEFT JOIN clients cl ON cl.id = cp.id_client
     ORDER BY co.date_mesure DESC
     LIMIT 200'
);
$rows = fetch_all_assoc($stmt);
$chronologicalRows = array_reverse($rows);

$totalRows = count($rows);
$avgVoltage = $totalRows ? array_sum(array_map(static fn($row) => (float) $row['tension'], $rows)) / $totalRows : 0;
$avgCurrent = $totalRows ? array_sum(array_map(static fn($row) => (float) $row['courant'], $rows)) / $totalRows : 0;
$maxPower = $totalRows ? max(array_map(static fn($row) => (float) $row['puissance'], $rows)) : 0;
$latestEnergy = $rows ? (float) $rows[0]['energie'] : 0;
$latestRow = $rows[0] ?? null;
$uniqueClients = count(array_unique(array_filter(array_column($rows, 'client_nom'))));
$uniqueMeters = count(array_unique(array_filter(array_column($rows, 'numero_compteur'))));

$chartLabels = json_encode(array_map(static fn($row) => substr((string) $row['date_mesure'], 5, 11), array_slice($chronologicalRows, -30)), JSON_UNESCAPED_UNICODE);
$chartVoltage = json_encode(array_map(static fn($row) => (float) $row['tension'], array_slice($chronologicalRows, -30)));
$chartPower = json_encode(array_map(static fn($row) => (float) $row['puissance'], array_slice($chronologicalRows, -30)));
$chartCurrent = json_encode(array_map(static fn($row) => (float) $row['courant'], array_slice($chronologicalRows, -30)));
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Consommations SmartGrid</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="/AdminLTE-4.0.0-rc7/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="/smartgrid_dashboard/assets/smartgrid-theme.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body{background:#0f1020;color:#fff;font-family:'Source Sans 3',sans-serif}.wrap{max-width:1280px;margin:0 auto;padding:32px}.panel{background:#181a2f;border:1px solid rgba(255,255,255,.07);border-radius:24px;padding:24px;box-shadow:0 18px 48px rgba(0,0,0,.28)}.table{color:#fff}.table>*{border-color:rgba(255,255,255,.06)!important}.muted{color:#a4acc4}.metric{border-radius:22px;padding:18px;min-height:132px;box-shadow:0 18px 38px rgba(0,0,0,.2);position:relative;overflow:hidden}.metric::after{content:"";position:absolute;right:-26px;top:-26px;width:96px;height:96px;border-radius:999px;background:rgba(255,255,255,.14)}.metric-icon{width:44px;height:44px;display:grid;place-items:center;border-radius:16px;background:rgba(255,255,255,.18);font-size:1.25rem}.tone-violet{background:linear-gradient(135deg,#6248ff,#8b7cff)}.tone-cyan{background:linear-gradient(135deg,#1686df,#4fd4ff)}.tone-orange{background:linear-gradient(135deg,#ff8f48,#ffc05f)}.tone-green{background:linear-gradient(135deg,#0da878,#2bd79f)}.status-badge{border-radius:999px;padding:.4rem .75rem;font-weight:700}.status-normal{background:rgba(41,211,145,.16);color:#74efbd}.status-low{background:rgba(255,180,77,.16);color:#ffd18a}.status-high{background:rgba(255,107,122,.16);color:#ff9da8}.filter-input{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);color:#fff;border-radius:16px}.filter-input::placeholder{color:#a4acc4}.last-card{background:linear-gradient(135deg,rgba(41,211,145,.14),rgba(73,184,255,.1));border:1px solid rgba(255,255,255,.08);border-radius:22px;padding:18px}.empty-state{text-align:center;color:#a4acc4;padding:28px}
  </style>
</head>
<body class="sg-admin">
<div class="wrap">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h1 class="h3 mb-1">Historique des consommations</h1>
      <div class="muted">Supervision des mesures recues depuis les compteurs ESP32/PZEM</div>
    </div>
    <div class="d-flex gap-2"><a class="btn btn-outline-light" href="/smartgrid_dashboard/admin/index.php">Dashboard</a><a class="btn btn-outline-light" href="/smartgrid_dashboard/logout.php">Deconnexion</a></div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6"><div class="metric tone-violet"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Tension moyenne</div><div class="display-6 fw-bold"><?= number_format($avgVoltage, 1) ?> V</div><div class="small">sur <?= $totalRows ?> mesures</div></div><div class="metric-icon"><i class="bi bi-lightning-charge"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-cyan"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Courant moyen</div><div class="display-6 fw-bold"><?= number_format($avgCurrent, 2) ?> A</div><div class="small"><?= $uniqueMeters ?> compteur(s)</div></div><div class="metric-icon"><i class="bi bi-activity"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-orange"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Puissance max</div><div class="display-6 fw-bold"><?= number_format($maxPower, 1) ?> W</div><div class="small">pic observe</div></div><div class="metric-icon"><i class="bi bi-speedometer2"></i></div></div></div></div>
    <div class="col-xl-3 col-md-6"><div class="metric tone-green"><div class="d-flex justify-content-between"><div><div class="small opacity-75">Derniere energie</div><div class="display-6 fw-bold"><?= number_format($latestEnergy, 3) ?> kWh</div><div class="small"><?= $uniqueClients ?> client(s)</div></div><div class="metric-icon"><i class="bi bi-battery-charging"></i></div></div></div></div>
  </div>

  <div class="row g-4 mb-4">
    <div class="col-xl-8">
      <div class="panel h-100">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div><h2 class="h5 mb-0">Evolution recente</h2><div class="muted small">Tension, courant et puissance des dernieres mesures</div></div>
          <span class="badge text-bg-dark">30 points</span>
        </div>
        <div style="height:340px"><canvas id="consumptionChart"></canvas></div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="panel h-100">
        <h2 class="h5 mb-3">Derniere mesure recue</h2>
        <?php if ($latestRow): ?>
          <div class="last-card">
            <div class="d-flex justify-content-between mb-3"><strong><?= htmlspecialchars($latestRow['numero_compteur'] ?? '-') ?></strong><span class="muted"><?= htmlspecialchars($latestRow['date_mesure']) ?></span></div>
            <div class="row g-3">
              <div class="col-6"><div class="muted small">Client</div><div class="fw-bold"><?= htmlspecialchars($latestRow['client_nom'] ?? '-') ?></div></div>
              <div class="col-6"><div class="muted small">Tension</div><div class="fw-bold"><?= number_format((float)$latestRow['tension'], 1) ?> V</div></div>
              <div class="col-6"><div class="muted small">Courant</div><div class="fw-bold"><?= number_format((float)$latestRow['courant'], 3) ?> A</div></div>
              <div class="col-6"><div class="muted small">Puissance</div><div class="fw-bold"><?= number_format((float)$latestRow['puissance'], 1) ?> W</div></div>
            </div>
          </div>
        <?php else: ?>
          <div class="empty-state">Aucune mesure disponible.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="panel">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
      <div><h2 class="h5 mb-0">Journal des mesures</h2><div class="muted small">Recherche par client, compteur ou date</div></div>
      <div class="d-flex gap-2 flex-wrap">
        <input class="form-control filter-input" id="consumption-search" placeholder="Rechercher...">
        <span class="badge text-bg-dark align-self-center" id="rows-count"><?= count($rows) ?> lignes</span>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead><tr><th>Date</th><th>Client</th><th>Compteur</th><th>Tension</th><th>Etat tension</th><th>Courant</th><th>Puissance</th><th>Energie</th></tr></thead>
        <tbody id="consumption-table-body">
        <?php foreach ($rows as $row): ?>
          <?php
            $voltage = (float) $row['tension'];
            $statusClass = 'status-normal';
            $statusLabel = 'Normale';
            if ($voltage > 0 && $voltage < 180) { $statusClass = 'status-low'; $statusLabel = 'Sous-tension'; }
            if ($voltage > 255) { $statusClass = 'status-high'; $statusLabel = 'Surtension'; }
          ?>
          <tr data-search="<?= htmlspecialchars(strtolower(($row['date_mesure'] ?? '') . ' ' . ($row['client_nom'] ?? '') . ' ' . ($row['numero_compteur'] ?? ''))) ?>">
            <td><?= htmlspecialchars($row['date_mesure']) ?></td>
            <td><?= htmlspecialchars($row['client_nom'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['numero_compteur'] ?? '-') ?></td>
            <td><?= number_format($voltage, 1) ?> V</td>
            <td><span class="status-badge <?= $statusClass ?>"><?= $statusLabel ?></span></td>
            <td><?= number_format((float)$row['courant'], 3) ?> A</td>
            <td><?= number_format((float)$row['puissance'], 1) ?> W</td>
            <td><?= number_format((float)$row['energie'], 3) ?> kWh</td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
const chartLabels = <?= $chartLabels ?>;
const chartVoltage = <?= $chartVoltage ?>;
const chartPower = <?= $chartPower ?>;
const chartCurrent = <?= $chartCurrent ?>;
new Chart(document.getElementById('consumptionChart'), {
  type: 'line',
  data: {
    labels: chartLabels,
    datasets: [
      { label: 'Tension (V)', data: chartVoltage, borderColor: '#8b7cff', backgroundColor: 'rgba(139,124,255,.12)', fill: true, tension: .35 },
      { label: 'Courant (A)', data: chartCurrent, borderColor: '#4fd4ff', backgroundColor: 'rgba(79,212,255,.08)', fill: true, tension: .35 },
      { label: 'Puissance (W)', data: chartPower, borderColor: '#ffb44d', backgroundColor: 'rgba(255,180,77,.08)', fill: true, tension: .35 }
    ]
  },
  options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { labels: { color: '#f8fbff' } } }, scales: { x: { ticks: { color: '#a4acc4' }, grid: { color: 'rgba(255,255,255,.05)' } }, y: { ticks: { color: '#a4acc4' }, grid: { color: 'rgba(255,255,255,.05)' } } } }
});

const search = document.getElementById('consumption-search');
const rowsCount = document.getElementById('rows-count');
search.addEventListener('input', () => {
  const query = search.value.trim().toLowerCase();
  let visible = 0;
  document.querySelectorAll('#consumption-table-body tr').forEach((row) => {
    const show = row.dataset.search.includes(query);
    row.style.display = show ? '' : 'none';
    if (show) visible += 1;
  });
  rowsCount.textContent = `${visible} lignes`;
});
</script>
</body>
</html>

