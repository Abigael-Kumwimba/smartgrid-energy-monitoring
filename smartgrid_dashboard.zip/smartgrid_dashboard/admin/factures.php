﻿<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/dashboard_data.php';

$user = smartgrid_require_login(['admin']);
$clients = fetch_clients_list();
$factures = fetch_factures_list();
$tarifKwh = (float) fetch_setting_value('tarif_kwh_residentiel', '0.15');
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Factures SmartGrid</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="/AdminLTE-4.0.0-rc7/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="/smartgrid_dashboard/assets/smartgrid-theme.css">
</head>
<body class="sg-admin">
<div class="wrap">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h1 class="h3 mb-1">Gestion des factures</h1>
      <div class="muted">Generation, consultation, impression et export PDF</div>
    </div>
    <div class="page-actions">
      <a class="btn btn-outline-light" href="/smartgrid_dashboard/admin/index.php">
        <i class="bi bi-grid me-1"></i> Dashboard
      </a>
      <a class="btn btn-outline-light" href="/smartgrid_dashboard/logout.php">
        <i class="bi bi-box-arrow-right me-1"></i> Deconnexion
      </a>
    </div>
  </div>

  <div class="row g-4">
    <div class="col-lg-4">
      <div class="panel h-100">
        <h2 class="h5 mb-3">Nouvelle facture</h2>
        <div class="soft-card mb-3">
          <div class="small muted">
            La facture est calculee automatiquement selon la consommation mesuree et le tarif par kWh.
          </div>
        </div>
        <div class="soft-card mb-3">
          <div class="d-flex justify-content-between align-items-center gap-2">
            <div>
              <div class="small muted">Tarif residentiel configure</div>
              <div class="fw-bold"><span id="current-tarif"><?= number_format($tarifKwh, 4, '.', '') ?></span> USD / kWh</div>
            </div>
            <button class="btn btn-outline-light btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#tarif-settings">Modifier</button>
          </div>
          <div class="collapse mt-3" id="tarif-settings">
            <form id="tarif-form" class="d-flex gap-2">
              <input class="form-control" name="tarif_kwh" type="number" step="0.0001" min="0.0001" value="<?= number_format($tarifKwh, 4, '.', '') ?>" required>
              <button class="btn btn-primary" type="submit">Enregistrer</button>
            </form>
            <div id="tarif-form-msg" class="small mt-2 muted"></div>
          </div>
        </div>
        <div id="facture-form-msg" class="small mb-3"></div>
        <form id="facture-form" class="d-grid gap-3">
          <select class="form-select" name="id_client" required>
            <?php foreach ($clients as $client): ?>
              <option value="<?= (int) $client['id'] ?>">
                <?= htmlspecialchars($client['nom']) ?> (#<?= (int) $client['id'] ?>)
              </option>
            <?php endforeach; ?>
          </select>
          <div class="row g-2">
            <div class="col-6">
              <label class="small muted mb-1" for="date_debut">Debut</label>
              <input id="date_debut" class="form-control" type="date" name="date_debut">
            </div>
            <div class="col-6">
              <label class="small muted mb-1" for="date_fin">Fin</label>
              <input id="date_fin" class="form-control" type="date" name="date_fin">
            </div>
          </div>
          <div>
            <label class="small muted mb-1" for="tarif_kwh">Tarif applique par kWh</label>
            <input id="tarif_kwh" class="form-control" name="tarif_kwh" type="number" step="0.0001" min="0.0001" value="<?= number_format($tarifKwh, 4, '.', '') ?>" required>
          </div>
          <button class="btn btn-primary" type="submit">
            <i class="bi bi-calculator me-1"></i> Calculer et generer
          </button>
        </form>
      </div>
    </div>

    <div class="col-lg-8">
      <div class="panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h2 class="h5 mb-0">Liste des factures</h2>
            <div class="muted small">Chaque facture peut etre ouverte, imprimee ou enregistree en PDF.</div>
          </div>
          <button class="btn btn-outline-light btn-sm" id="reload-factures" type="button">
            <i class="bi bi-arrow-clockwise me-1"></i> Actualiser
          </button>
        </div>

        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
            <tr>
              <th>ID</th>
              <th>Client</th>
              <th>Montant</th>
              <th>Energie</th>
              <th>Statut</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody id="factures-table-body">
            <?php foreach ($factures as $facture): ?>
              <tr>
                <td><?= (int) $facture['id'] ?></td>
                <td><?= htmlspecialchars($facture['client_nom'] ?? '-') ?></td>
                <td>$<?= number_format((float) $facture['montant'], 2) ?></td>
                <td>
                  <?= $facture['energie_totale'] !== null
                    ? number_format((float) $facture['energie_totale'], 2) . ' kWh'
                    : '-' ?>
                </td>
                <td>
                  <span class="badge <?= $facture['statut'] === 'payee' ? 'text-bg-success' : 'text-bg-warning' ?>">
                    <?= htmlspecialchars($facture['statut']) ?>
                  </span>
                </td>
                <td><?= htmlspecialchars($facture['date_facture']) ?></td>
                <td>
                  <a class="btn btn-sm btn-primary" href="/smartgrid_dashboard/smartgrid_app/facture_detail.php?id=<?= (int) $facture['id'] ?>">
                    <i class="bi bi-printer me-1"></i> Voir
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="/AdminLTE-4.0.0-rc7/dist/js/adminlte.min.js"></script>
<script>
async function fetchJson(url, options = {}) {
  const response = await fetch(url, { headers: { 'Accept': 'application/json' }, ...options });
  return response.json();
}

function renderFactures(factures, clientMap) {
  const rows = factures.map((facture) => {
    const id = Number(facture.id || 0);
    const client = clientMap[String(facture.id_client)] || facture.client_nom || facture.id_client || '-';
    const energie = facture.energie_totale !== null && facture.energie_totale !== undefined
      ? `${Number(facture.energie_totale).toFixed(2)} kWh`
      : '-';
    const badge = facture.statut === 'payee' ? 'text-bg-success' : 'text-bg-warning';

    return `
      <tr>
        <td>${id}</td>
        <td>${client}</td>
        <td>$${Number(facture.montant || 0).toFixed(2)}</td>
        <td>${energie}</td>
        <td><span class="badge ${badge}">${facture.statut || ''}</span></td>
        <td>${facture.date_facture || ''}</td>
        <td>
          <a class="btn btn-sm btn-primary" href="/smartgrid_dashboard/smartgrid_app/facture_detail.php?id=${id}">
            <i class="bi bi-printer me-1"></i> Voir
          </a>
        </td>
      </tr>
    `;
  }).join('');

  document.getElementById('factures-table-body').innerHTML = rows;
}

async function loadFactures() {
  const [factures, clients] = await Promise.all([
    fetchJson('/smartgrid_energy_api/factures/read_factures.php'),
    fetchJson('/smartgrid_energy_api/clients/read_clients.php')
  ]);
  const clientMap = Object.fromEntries(clients.map((client) => [String(client.id), client.nom]));
  renderFactures(factures, clientMap);
}

document.getElementById('reload-factures').addEventListener('click', loadFactures);
document.getElementById('tarif-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);
  const response = await fetch('/smartgrid_dashboard/smartgrid_app/api/update_tarif.php', {
    method: 'POST',
    body: form
  });
  const data = await response.json();
  const messageBox = document.getElementById('tarif-form-msg');
  messageBox.textContent = data.message || 'Tarif mis a jour';
  if (data.status === 'success') {
    const tarif = Number(data.tarif_kwh || 0).toFixed(4);
    document.getElementById('current-tarif').textContent = tarif;
    document.getElementById('tarif_kwh').value = tarif;
  }
});
document.getElementById('facture-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);
  const response = await fetch('/smartgrid_energy_api/factures/generate_facture.php', {
    method: 'POST',
    body: form
  });
  const data = await response.json();
  const messageBox = document.getElementById('facture-form-msg');
  if (data.status === 'success') {
    messageBox.textContent = `${data.message} : ${Number(data.energie_totale || 0).toFixed(3)} kWh x ${Number(data.tarif_kwh || 0).toFixed(2)} = $${Number(data.montant || 0).toFixed(2)}`;
    event.target.reset();
    loadFactures();
  } else {
    messageBox.textContent = data.message || 'Impossible de generer la facture';
  }
});
</script>
</body>
</html>
