﻿<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=UTF-8');

$sql = 'SELECT cp.id, cp.numero_compteur, cp.id_client, cp.statut, cp.date_installation,
               MAX(co.date_mesure) AS derniere_mesure,
               COUNT(co.id) AS total_mesures,
               COALESCE(SUM(CASE WHEN f.statut = "non_payee" THEN 1 ELSE 0 END), 0) AS factures_non_payees
        FROM compteurs cp
        LEFT JOIN consommations co ON co.id_compteur = cp.id
        LEFT JOIN clients cl ON cl.id = cp.id_client
        LEFT JOIN factures f ON f.id_client = cl.id
        GROUP BY cp.id, cp.numero_compteur, cp.id_client, cp.statut, cp.date_installation
        ORDER BY cp.id DESC';
$result = $conn->query($sql);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
?>
